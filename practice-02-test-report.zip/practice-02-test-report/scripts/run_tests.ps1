param (
    [string]$cmd,
    [string]$out = "reports",
    [string]$format = "text",
    [string]$run_id = "",
    [string]$project = ""
)

if (-not $cmd) {
    Write-Host "Помилка: не вказано команду тестів"
    Write-Host "Приклад запуску: .\run_tests.ps1 -cmd 'python -m pytest -q'"
    exit 2
}

if (-not $run_id) { $run_id = Get-Date -Format "yyyyMMddHHmmss" }
if (-not $project) { $project = (Get-Location).Path.Split('\')[-1] }

$runDir = Join-Path $out "runs\$run_id"
$rawDir = Join-Path $runDir "raw"
$summaryDir = Join-Path $runDir "summary"
$htmlDir = Join-Path $runDir "html"

New-Item -ItemType Directory -Force -Path $rawDir,$summaryDir
if ($format -eq "html") { New-Item -ItemType Directory -Force -Path $htmlDir }

Write-Host "Запуск: $cmd"
Write-Host "Результати збережуться у $runDir"

Invoke-Expression "$cmd *>&1" | Tee-Object -FilePath (Join-Path $rawDir "test_output.txt")
$exitCode = $LASTEXITCODE

# --- Статистика ---
$rawFile = Join-Path $rawDir "test_output.txt"
$errorCount = (Select-String "ERROR" $rawFile).Count
$failedCount = (Select-String "FAILED" $rawFile).Count

$first5 = (Select-String "ERROR|FAILED" $rawFile | Select-Object -First 5).Line
$last5 = (Select-String "ERROR|FAILED" $rawFile | Select-Object -Last 5).Line

$status = if ($exitCode -eq 0) { "SUCCESS" } else { "FAIL" }

# --- Метадані ---
@"
project: $project
run_id: $run_id
datetime: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
command: $cmd
"@ | Out-File (Join-Path $summaryDir "meta.txt")

$status | Out-File (Join-Path $summaryDir "status.txt")
@("ERROR=$errorCount","FAILED=$failedCount") | Out-File (Join-Path $summaryDir "stats.txt")

# --- Текстовий звіт ---
$reportFile = Join-Path $runDir "report.txt"
@"
Проєкт: $project
Дата/Час: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Команда тестів: $cmd
Статус: $status
Шлях до логу: $rawFile
Статистика:
  ERROR: $errorCount
  FAILED: $failedCount
Перші 5 рядків з ERROR/FAILED:
$($first5 -join "`n")
Останні 5 рядків з ERROR/FAILED:
$($last5 -join "`n")
"@ | Out-File $reportFile

# --- HTML-звіт ---
if ($format -eq "html") {
    $htmlFile = Join-Path $htmlDir "report.html"
    @"
<html>
<head><title>Test Report</title></head>
<body>
<h2>Проєкт: $project</h2>
<p>Дата/Час: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")</p>
<p>Команда тестів: $cmd</p>
<p>Статус: <b>$status</b></p>
<p>Шлях до raw-логу: $rawFile</p>
<p>Статистика: ERROR=$errorCount, FAILED=$failedCount</p>
</body>
</html>
"@ | Out-File $htmlFile
}

exit $exitCode